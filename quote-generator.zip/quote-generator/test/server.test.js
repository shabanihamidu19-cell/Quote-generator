'use strict';

const request = require('supertest');
const { createApp, QUOTES, VALID_CATEGORIES } = require('../src/server');

const app = createApp();

describe('GET /health', () => {
  it('inarudisha status ok na idadi ya nukuu', async () => {
    const res = await request(app).get('/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ok');
    expect(res.body.quotes).toBe(QUOTES.length);
  });
});

describe('GET /api/categories', () => {
  it('inarudisha orodha ya kategoria zote', async () => {
    const res = await request(app).get('/api/categories');
    expect(res.status).toBe(200);
    expect(res.body.categories).toEqual(expect.arrayContaining(VALID_CATEGORIES));
  });
});

describe('GET /api/quotes', () => {
  it('inarudisha nukuu zote bila kichujio', async () => {
    const res = await request(app).get('/api/quotes');
    expect(res.status).toBe(200);
    expect(res.body.quotes.length).toBe(QUOTES.length);
  });

  it('inachuja kwa kategoria sahihi', async () => {
    const res = await request(app).get('/api/quotes?category=elimu');
    expect(res.status).toBe(200);
    expect(res.body.quotes.length).toBeGreaterThan(0);
    res.body.quotes.forEach((q) => expect(q.category).toBe('elimu'));
  });

  it('inarudisha 404 kwa kategoria isiyokuwepo', async () => {
    const res = await request(app).get('/api/quotes?category=hakuna');
    expect(res.status).toBe(404);
    expect(res.body.error).toBe('category_not_found');
  });
});

describe('GET /api/quotes/random', () => {
  it('inarudisha nukuu moja ya nasibu', async () => {
    const res = await request(app).get('/api/quotes/random');
    expect(res.status).toBe(200);
    expect(res.body.quote).toHaveProperty('text');
    expect(res.body.quote).toHaveProperty('author');
  });

  it('inaheshimu kichujio cha kategoria', async () => {
    const res = await request(app).get('/api/quotes/random?category=bidii');
    expect(res.status).toBe(200);
    expect(res.body.quote.category).toBe('bidii');
  });

  it('inarudisha 404 kwa kategoria isiyokuwepo', async () => {
    const res = await request(app).get('/api/quotes/random?category=hakuna');
    expect(res.status).toBe(404);
  });
});

describe('GET /api/quotes/:id', () => {
  it('inarudisha nukuu sahihi kwa id', async () => {
    const res = await request(app).get('/api/quotes/1');
    expect(res.status).toBe(200);
    expect(res.body.quote.id).toBe(1);
  });

  it('inarudisha 404 kwa id isiyokuwepo', async () => {
    const res = await request(app).get('/api/quotes/9999');
    expect(res.status).toBe(404);
    expect(res.body.error).toBe('not_found');
  });
});

describe('Njia zisizojulikana', () => {
  it('inarudisha 404 kwa njia isiyofafanuliwa', async () => {
    const res = await request(app).get('/haipo');
    expect(res.status).toBe(404);
  });
});
