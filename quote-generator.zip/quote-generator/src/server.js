'use strict';

const express = require('express');

const QUOTES = [
  { id: 1, text: 'Elimu ni silaha yenye nguvu zaidi unayoweza kuitumia kubadilisha dunia.', author: 'Nelson Mandela', category: 'elimu' },
  { id: 2, text: "Bidii ya leo ndiyo mafanikio ya kesho. Usisubiri hali kuwa nzuri, ianzishe.", author: 'Msemo wa Kiswahili', category: 'bidii' },
  { id: 3, text: "Aliyeamua kufaulu, kwake hakuna neno 'haiwezekani'.", author: 'Msemo wa Kiswahili', category: 'mafanikio' },
  { id: 4, text: 'Ujuzi si mzigo wa kubeba, ni mwanga wa kuangaza njia yako.', author: 'Msemo wa Kiswahili', category: 'elimu' },
  { id: 5, text: 'Safari ya maili elfu huanza kwa hatua moja.', author: 'Lao Tzu', category: 'maisha' },
  { id: 6, text: 'Usiache ndoto zako zife kwa sababu ya uvivu wa dakika hii.', author: 'Msemo wa Kiswahili', category: 'bidii' },
  { id: 7, text: 'Mtu anayesoma leo ndiye kiongozi wa kesho.', author: 'Msemo wa Kiswahili', category: 'elimu' },
  { id: 8, text: 'Kila jitihada ndogo unayofanya leo, inajenga mafanikio makubwa ya kesho.', author: 'Msemo wa Kiswahili', category: 'bidii' },
  { id: 9, text: 'Kushindwa si mwisho wa safari, ni sehemu tu ya njia ya mafanikio.', author: 'Msemo wa Kiswahili', category: 'mafanikio' },
  { id: 10, text: 'Elimu si kile unachokumbuka, ni uwezo wa kufikiri unaoupata.', author: 'Albert Einstein', category: 'elimu' },
  { id: 11, text: 'Usiogope kuanza tena. Hii si mara ya kwanza kujenga kitu kutoka mwanzo.', author: 'Msemo wa Kiswahili', category: 'maisha' },
  { id: 12, text: 'Mafanikio hayaji kwa bahati, huja kwa maandalizi yanapokutana na fursa.', author: 'Msemo wa Kiswahili', category: 'mafanikio' },
  { id: 13, text: 'Jitihada ndogo ya kila siku, baada ya muda huwa mlima wa mafanikio.', author: 'Msemo wa Kiswahili', category: 'bidii' },
  { id: 14, text: 'Kitabu kimoja kinaweza kubadilisha maisha elfu moja.', author: 'Msemo wa Kiswahili', category: 'elimu' },
  { id: 15, text: 'Usilinganishe safari yako na ya mwingine — kila mmoja ana wakati wake.', author: 'Msemo wa Kiswahili', category: 'maisha' },
  { id: 16, text: 'Anayetafuta hupata. Anayesubiri tu, hukaa pale pale.', author: 'Msemo wa Kiswahili', category: 'bidii' },
  { id: 17, text: 'Fikra kubwa huanzia kwenye kichwa kidogo chenye ndoto kubwa.', author: 'Msemo wa Kiswahili', category: 'mafanikio' },
  { id: 18, text: 'Kila mtaalamu alikuwa mwanzoni mwanafunzi tu.', author: 'Msemo wa Kiswahili', category: 'elimu' },
  { id: 19, text: 'Maisha hayapimwi kwa miaka uliyoishi, bali kwa alama ulizoacha.', author: 'Msemo wa Kiswahili', category: 'maisha' },
  { id: 20, text: 'Usisite kuuliza. Swali moja linaweza kufungua mlango wa maarifa mengi.', author: 'Msemo wa Kiswahili', category: 'elimu' },
  { id: 21, text: 'Watu wenye mafanikio hawakuwa na urahisi zaidi — walikuwa na uvumilivu zaidi.', author: 'Msemo wa Kiswahili', category: 'mafanikio' },
  { id: 22, text: 'Kesho ni matokeo ya maamuzi unayofanya leo.', author: 'Msemo wa Kiswahili', category: 'maisha' },
  { id: 23, text: 'Mwanafunzi bora si aliyekamilika, ni yule asiyeacha kujaribu.', author: 'Msemo wa Kiswahili', category: 'elimu' },
  { id: 24, text: 'Nguvu haitoki kwenye kile unachoweza kufanya, hutoka kwenye kushinda kile ulichodhani huwezi.', author: 'Msemo wa Kiswahili', category: 'bidii' },
  { id: 25, text: 'Fanya kile unachoweza, ukitumia ulichonacho, pale ulipo.', author: 'Theodore Roosevelt', category: 'maisha' }
];

const VALID_CATEGORIES = [...new Set(QUOTES.map((q) => q.category))];

function createApp() {
  const app = express();
  app.disable('x-powered-by');
  app.use(express.json());

  // Afya ya huduma — inatumika na Render/Docker healthcheck
  app.get('/health', (req, res) => {
    res.status(200).json({ status: 'ok', quotes: QUOTES.length });
  });

  // Orodha ya kategoria zilizopo
  app.get('/api/categories', (req, res) => {
    res.json({ categories: VALID_CATEGORIES });
  });

  // Nukuu zote, na uchujaji wa hiari kwa ?category=
  app.get('/api/quotes', (req, res) => {
    const { category } = req.query;
    if (category) {
      if (!VALID_CATEGORIES.includes(category)) {
        return res.status(404).json({
          error: 'category_not_found',
          message: `Kategoria '${category}' haipo.`,
          categories: VALID_CATEGORIES,
        });
      }
      return res.json({ quotes: QUOTES.filter((q) => q.category === category) });
    }
    res.json({ quotes: QUOTES });
  });

  // Nukuu moja ya nasibu, na uchujaji wa hiari kwa ?category=
  app.get('/api/quotes/random', (req, res) => {
    const { category } = req.query;
    let pool = QUOTES;

    if (category) {
      if (!VALID_CATEGORIES.includes(category)) {
        return res.status(404).json({
          error: 'category_not_found',
          message: `Kategoria '${category}' haipo.`,
          categories: VALID_CATEGORIES,
        });
      }
      pool = QUOTES.filter((q) => q.category === category);
    }

    const quote = pool[Math.floor(Math.random() * pool.length)];
    res.json({ quote });
  });

  // Nukuu moja kwa ID
  app.get('/api/quotes/:id', (req, res) => {
    const id = Number(req.params.id);
    const quote = QUOTES.find((q) => q.id === id);
    if (!quote) {
      return res.status(404).json({ error: 'not_found', message: `Nukuu yenye id=${id} haipo.` });
    }
    res.json({ quote });
  });

  // 404 ya jumla
  app.use((req, res) => {
    res.status(404).json({ error: 'not_found', message: 'Njia hii haipo.' });
  });

  return app;
}

if (require.main === module) {
  const PORT = process.env.PORT || 3000;
  const app = createApp();
  app.listen(PORT, () => {
    console.log(`Quote Generator API inaendesha kwenye port ${PORT}`);
  });
}

module.exports = { createApp, QUOTES, VALID_CATEGORIES };
